DELETE From movies Where movieid = 7;
